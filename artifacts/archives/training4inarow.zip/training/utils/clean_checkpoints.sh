#!/bin/bash
rm -rf checkpoints/*
echo "Checkpoints cleared."
